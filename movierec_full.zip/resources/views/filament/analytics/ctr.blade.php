<x-filament-panels::page>
  <iframe src="{{ route('admin.ctr') }}" style="width:100%;height:1200px;border:0;"></iframe>
</x-filament-panels::page>
