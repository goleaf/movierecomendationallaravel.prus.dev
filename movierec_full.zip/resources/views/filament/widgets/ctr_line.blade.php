<x-filament-widgets::widget>
  <img src="{{ route('admin.ctr.svg') }}" alt="CTR line"/>
</x-filament-widgets::widget>
