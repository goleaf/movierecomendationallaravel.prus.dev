<x-filament-widgets::widget>
  <img src="{{ route('admin.ctr.bars.svg') }}" alt="CTR bars"/>
</x-filament-widgets::widget>
