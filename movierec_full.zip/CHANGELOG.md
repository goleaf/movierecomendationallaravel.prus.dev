# Changelog (All-in-One)

2025-10-19 — Ultimate bundle: CTR (SVG line/bars), z-test, funnels (genre/year), i18n (TMDB), 
RSS, Trends, Filament Analytics (CTR/Trends/Queue/Horizon, SSR stats & drops), 
SSR on-the-fly metrics & issues API, typed controllers/services, PHPStan lvl7, search filters & DB indexes.
