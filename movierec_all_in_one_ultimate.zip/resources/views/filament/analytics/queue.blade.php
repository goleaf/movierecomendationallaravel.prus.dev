<x-filament-panels::page>
  <iframe src="{{ route('admin.metrics') }}" style="width:100%;height:800px;border:0;"></iframe>
</x-filament-panels::page>
