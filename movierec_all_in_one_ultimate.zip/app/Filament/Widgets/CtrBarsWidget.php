<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class CtrBarsWidget extends Widget
{
    protected static string $view='filament.widgets.ctr_bars';
}
