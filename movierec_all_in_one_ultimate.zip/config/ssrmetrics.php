<?php

return [
    'enabled' => env('SSR_METRICS', false),
    'paths' => ['/', '/trends', '/admin/ctr'],
];
